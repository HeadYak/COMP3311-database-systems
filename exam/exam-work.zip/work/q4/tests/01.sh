psql music -c 'select * from q4() order by "group" collate "en_AU";'
