-- COMP3311 20T3 Final Exam
-- Q3:  performer(s) who play many instruments

-- ... helper views (if any) go here ...

create or replace view q3(performer,ninstruments)
as
...put your SQL here...
;

