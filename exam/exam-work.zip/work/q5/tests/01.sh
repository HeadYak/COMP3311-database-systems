psql music -c 'select * from q5() order by "group";'
